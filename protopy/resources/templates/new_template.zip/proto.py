# this is the main template logic.
# after the execution of this file, the module variables will be visible to all the files that are going to be generated 

# you can ask the user for input like this:
project_name = ask(named_arg='project_name', prompt='Gimmi yo project name')

# you can also set default
author = ask('author', 'Who you?', default="no one")

# you can restrict input to set of choises
readme_type = ask('readme_type', 'Type of readme ya\'like', default=0, choices=["Markdown", "reStructuredText"])

# you can create module variables like any python module - you don't have to ask for them.. 
readme_ext = 'md' if readme_type == "Markdown" else 'rst'

# when calling from the commandline the user can supply named args and positional args,
# in the example below, if the user executed protopy with either the commands:
# > protopy <your template name> 3.6
# > protopy <your template name> python_ver=3.6
# then the user will not get any prompt and the value '3.6' will be returned 
python_ver = ask('python_ver', 'Snake version', '^3.8', positional_arg=0)

# Check out the docs for more information..
